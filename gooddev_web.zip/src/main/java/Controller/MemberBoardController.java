package Controller;

public class MemberBoardController {

}
